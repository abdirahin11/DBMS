package so.edu.hodmas.ims.hucims.models;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import so.edu.hodmas.ims.hucims.HUCIMSApplication;

import java.io.IOException;

public class LoginPage {

    @FXML
    private PasswordField password;

    @FXML
    private Label error;

    @FXML
    private TextField username;

    String usern = "admin";
    String passw = "admin";

    @FXML
    void loginPage(ActionEvent event) throws IOException {
        String user = username.getText();
        String pass = password.getText();
        if (user.equals(usern) && pass.equals(passw)) {
            changeScene(event);
        } else {
            error.setText("Enter Valid username and password");
        }
    }
    @FXML
    public void changeScene(ActionEvent event) throws IOException{
        Button btn = ((Button)event.getSource());
        Stage stage = (Stage) btn.getScene().getWindow();

        FXMLLoader fxmlLoader = new FXMLLoader(HUCIMSApplication.class.getResource("views/dashboard.fxml"));

        Scene scene = new Scene(fxmlLoader.load(), 1200, 850);
        stage.setTitle(btn.getText() + " HUC-IMS");
        stage.setScene(scene);
    }
}